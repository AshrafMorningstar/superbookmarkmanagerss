how to Use This Bot:
Save the codeas language_generator.py

Run the bot (no clicking needed):

bash
python language_generator.py