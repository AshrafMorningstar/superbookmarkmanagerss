/*
 * Created by: Ashraf Morningstar
 * GitHub: https://github.com/AshrafMorningstar
 * Generation Timestamp: 2025-11-13T11:17:00.649Z
 * Language: JavaScript
 */

console.log("Hello, World!");

function add(a, b) {
    // A function that adds two numbers
    return a + b;
}

console.log(`2 + 3 = ${add(2, 3)}`);