/*
 * Created by: Ashraf Morningstar
 * GitHub: https://github.com/AshrafMorningstar
 * Generation Timestamp: 2025-11-13T11:17:00.672Z
 * Language: Objective-C
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSLog(@"Hello, World!");
    }
    return 0;
}