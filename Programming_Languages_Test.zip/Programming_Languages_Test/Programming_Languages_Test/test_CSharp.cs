/*
 * Created by: Ashraf Morningstar
 * GitHub: https://github.com/AshrafMorningstar
 * Generation Timestamp: 2025-11-13T11:17:00.649Z
 * Language: CSharp
 */

using System;

public class Program {
    public static void Main() {
        Console.WriteLine("Hello, World!");
    }
}