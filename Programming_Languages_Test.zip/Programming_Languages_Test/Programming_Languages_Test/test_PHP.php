/*
 * Created by: Ashraf Morningstar
 * GitHub: https://github.com/AshrafMorningstar
 * Generation Timestamp: 2025-11-13T11:17:00.649Z
 * Language: PHP
 */

<?php
echo "Hello, World!";

function greet($name) {
    return "Hello, " . $name;
}
?>