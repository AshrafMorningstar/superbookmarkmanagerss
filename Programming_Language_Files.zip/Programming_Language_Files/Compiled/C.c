// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

#include <stdio.h>

int main() {
   printf("Hello, World!");
   return 0;
}