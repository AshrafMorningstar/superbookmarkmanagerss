// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

#include <iostream>

int main() {
    std::cout << "Hello, World!";
    return 0;
}