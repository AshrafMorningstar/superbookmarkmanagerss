// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}