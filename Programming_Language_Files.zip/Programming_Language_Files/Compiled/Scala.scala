// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

object HelloWorld {
  def main(args: Array[String]): Unit = {
    println("Hello, world!")
  }
}