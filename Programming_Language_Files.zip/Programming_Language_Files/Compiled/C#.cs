// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

using System;

class Program {
    static void Main(string[] args) {
        Console.WriteLine("Hello, World!");
    }
}