-- Created by: Ashraf Morningstar
-- GitHub: https://github.com/AshrafMorningstar

SELECT 'Hello, World!';