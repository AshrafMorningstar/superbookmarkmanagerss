% Created by: Ashraf Morningstar
% GitHub: https://github.com/AshrafMorningstar

disp('Hello, World!')