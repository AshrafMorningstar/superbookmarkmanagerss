// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

printfn "Hello, World!"