(*
Created by: Ashraf Morningstar
GitHub: https://github.com/AshrafMorningstar
*)

print_endline "Hello, World!"