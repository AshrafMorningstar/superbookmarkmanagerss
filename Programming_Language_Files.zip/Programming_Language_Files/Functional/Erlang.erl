% Created by: Ashraf Morningstar
% GitHub: https://github.com/AshrafMorningstar

-module(helloworld).
-export([start/0]).

start() ->
    io:fwrite("Hello, world\n").