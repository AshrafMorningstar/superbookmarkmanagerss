-- Created by: Ashraf Morningstar
-- GitHub: https://github.com/AshrafMorningstar

main :: IO ()
main = putStrLn "Hello, World!"