# Created by: Ashraf Morningstar
# GitHub: https://github.com/AshrafMorningstar

IO.puts "Hello, World!"