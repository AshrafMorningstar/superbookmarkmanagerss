' Created by: Ashraf Morningstar
' GitHub: https://github.com/AshrafMorningstar

Module HelloWorld
    Sub Main()
        Console.WriteLine("Hello, World!")
    End Sub
End Module