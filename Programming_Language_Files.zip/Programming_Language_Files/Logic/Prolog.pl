% Created by: Ashraf Morningstar
% GitHub: https://github.com/AshrafMorningstar

:- initialization(main).
main :- write('Hello, World!'), nl.