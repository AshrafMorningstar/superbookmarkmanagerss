// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

console.log("Hello, World!");