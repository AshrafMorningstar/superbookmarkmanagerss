# Created by: Ashraf Morningstar
# GitHub: https://github.com/AshrafMorningstar

Write-Host "Hello, World!"