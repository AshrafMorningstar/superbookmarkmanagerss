# Created by: Ashraf Morningstar
# GitHub: https://github.com/AshrafMorningstar

#!/bin/bash

echo "Hello, World!"