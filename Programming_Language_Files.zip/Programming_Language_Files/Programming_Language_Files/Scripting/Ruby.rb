# Created by: Ashraf Morningstar
# GitHub: https://github.com/AshrafMorningstar

puts "Hello, World!"