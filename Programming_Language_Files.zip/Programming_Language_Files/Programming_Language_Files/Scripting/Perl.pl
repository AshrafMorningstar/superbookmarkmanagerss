# Created by: Ashraf Morningstar
# GitHub: https://github.com/AshrafMorningstar

use strict;
use warnings;

print "Hello, World!\n";