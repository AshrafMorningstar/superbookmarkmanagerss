// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

fun main() {
    println("Hello, World!")
}