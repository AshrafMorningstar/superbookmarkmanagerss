// Created by: Ashraf Morningstar
// GitHub: https://github.com/AshrafMorningstar

void main() {
  print('Hello, World!');
}