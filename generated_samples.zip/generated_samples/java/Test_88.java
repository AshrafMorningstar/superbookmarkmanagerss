// Test_88.java
// Generated: 2025-11-14T06:20:09.785199Z
public class Test88 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
