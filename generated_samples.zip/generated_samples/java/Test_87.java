// Test_87.java
// Generated: 2025-11-14T06:20:09.785588Z
public class Test87 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
