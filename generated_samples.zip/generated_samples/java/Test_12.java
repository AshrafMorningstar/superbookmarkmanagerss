// Test_12.java
// Generated: 2025-11-14T06:20:09.742424Z
public class Test12 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
