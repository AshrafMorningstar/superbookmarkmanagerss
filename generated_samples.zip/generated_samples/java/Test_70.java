// Test_70.java
// Generated: 2025-11-14T06:20:09.778166Z
public class Test70 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
