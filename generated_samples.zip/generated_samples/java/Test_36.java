// Test_36.java
// Generated: 2025-11-14T06:20:09.768832Z
public class Test36 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
