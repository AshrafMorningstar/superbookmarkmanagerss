// Test_14.java
// Generated: 2025-11-14T06:20:09.766659Z
public class Test14 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
