// Test_55.java
// Generated: 2025-11-14T06:20:09.776639Z
public class Test55 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
