// Test_34.java
// Generated: 2025-11-14T06:20:09.766942Z
public class Test34 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
