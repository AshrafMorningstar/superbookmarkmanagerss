/* test_25.c
 * Generated: 2025-11-14T06:20:09.795507Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
