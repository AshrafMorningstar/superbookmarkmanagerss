/* test_79.c
 * Generated: 2025-11-14T06:20:09.807711Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
