/* test_47.c
 * Generated: 2025-11-14T06:20:09.801392Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
