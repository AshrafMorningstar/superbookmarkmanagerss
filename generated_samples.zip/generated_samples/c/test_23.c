/* test_23.c
 * Generated: 2025-11-14T06:20:09.793226Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
