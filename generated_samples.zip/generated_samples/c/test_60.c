/* test_60.c
 * Generated: 2025-11-14T06:20:09.803641Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
