// test_50.cpp
// Generated: 2025-11-14T06:20:09.827687Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
