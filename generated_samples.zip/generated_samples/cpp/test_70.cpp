// test_70.cpp
// Generated: 2025-11-14T06:20:09.829631Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
