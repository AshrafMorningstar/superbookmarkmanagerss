// test_23.cpp
// Generated: 2025-11-14T06:20:09.820129Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
