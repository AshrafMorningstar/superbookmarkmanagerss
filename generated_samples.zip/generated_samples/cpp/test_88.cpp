// test_88.cpp
// Generated: 2025-11-14T06:20:09.837149Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
