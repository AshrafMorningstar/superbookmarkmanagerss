// test_52.cpp
// Generated: 2025-11-14T06:20:09.828510Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
