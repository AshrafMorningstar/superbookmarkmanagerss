// test_21.cpp
// Generated: 2025-11-14T06:20:09.819999Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
