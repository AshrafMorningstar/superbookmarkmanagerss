// test_64.cpp
// Generated: 2025-11-14T06:20:09.829061Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
