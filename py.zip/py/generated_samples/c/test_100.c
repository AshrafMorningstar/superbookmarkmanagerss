/* test_100.c
 * Generated: 2025-11-13T18:06:56.910977Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
