/* test_73.c
 * Generated: 2025-11-13T18:06:56.902538Z
 */
#include <stdio.h>

int main(void) {
    printf("Hello, World!\n");
    return 0;
}
