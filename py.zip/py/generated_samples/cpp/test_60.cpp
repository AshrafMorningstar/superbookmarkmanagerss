// test_60.cpp
// Generated: 2025-11-13T18:06:56.934892Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
