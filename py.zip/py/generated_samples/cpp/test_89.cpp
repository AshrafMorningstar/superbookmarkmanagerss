// test_89.cpp
// Generated: 2025-11-13T18:06:56.942701Z
#include <iostream>
#include <string>

int main() {
    std::string name = "World";
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
