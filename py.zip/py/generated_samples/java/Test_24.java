// Test_24.java
// Generated: 2025-11-13T18:06:56.811561Z
public class Test24 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
