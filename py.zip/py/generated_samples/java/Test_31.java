// Test_31.java
// Generated: 2025-11-13T18:06:56.809534Z
public class Test31 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
