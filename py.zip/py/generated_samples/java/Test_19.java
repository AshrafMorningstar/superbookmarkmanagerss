// Test_19.java
// Generated: 2025-11-13T18:06:56.809187Z
public class Test19 {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }
    public static void main(String[] args) {
        System.out.println(greet("World"));
    }
}
